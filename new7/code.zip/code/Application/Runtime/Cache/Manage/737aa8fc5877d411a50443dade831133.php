<?php if (!defined('THINK_PATH')) exit();?>
<div><a href="http://localhost:8080/GIT/ht/code/index.php/manage/data/registerQuery?patient_id=123&export=1">导出</a></div> 

<img src="../public/img/payment_module/hos_pay.png">