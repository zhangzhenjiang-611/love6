<?php
namespace Manage\Controller;
use Think\Controller;
class LoginController extends Controller {
	
	public function index(){
		$this->display();
	}

	/**
     * @desc 登陆验证
     * @param
     * @author 鲁翠霞
     * @final 2020-04-21
     */

	public function check(){
		//1是必传参数
		$rules = array(
			array('username',1),
			array('password',1),
		);
		$in = validParam($rules);//入参处理
		// $in['username'] = 'admin';
		// $in['password'] = '123456';
		$username = $in['username'];
		$password = md5($in['password']);
		$ob = M("user");
		$re = $ob->where("username='{$username}' and password='{$password}' and status='1'")->select();
		if($re){
			
				//记录登陆时间、ip
				if($_SERVER["REMOTE_ADDR"]=='::1'){
					$ip = '127.0.0.1';
				}else{
					$ip = $_SERVER["REMOTE_ADDR"];
				}
				$up = array(
				'login_time' => date('Y-m-d H:i:s'),
				'login_ip' => $ip
				);
				M('user')->where("id ='".$re['0']['id']."'")->save($up);
				session('uname',$username);
				session('uid',$re[0]['id']);
				session(C('USER_AUTH_KEY'),$re['0']['id']);
				
				if($_SESSION['uname']==C('RBAC_SUPERADMIN')){
					session(C('ADMIN_AUTH_KEY'),true);
				}
				
				//RBAC
				$t1=new \Org\Util\Rbac();
				
				$t1::saveAccessList(); 
				$rel['code']='0';
				$rel['msg']='登陆成功';
		}else{
			$rel['code']='1';
			$rel['msg']='用户名密码错误';
		}
		//dump($rel);exit;
		$this->ajaxReturn($rel,'JSON');
	}


	/**
     * @desc 退出登陆
     * @param
     * @author 鲁翠霞
     * @final 2020-04-21
     */
	public function loginOut(){
        session_start(); //开启Session功能
		session_destroy();
		$rel['code']='0';
		$rel['msg']='退出登陆成功';
		
		$this->ajaxReturn($rel,'JSON');
        //$this->redirect($url);//重定向到新的模块
		
    }
    

	
	/**
     * @desc 修改密码
     * @param
     * @author 鲁翠霞
     * @final 2020-04-21
     */
	public function reg(){
		$rules = array(
			//array('username',1),
			array('password',1),
		);
		$in = validParam($rules);//入参处理
		session_start(); //开启Session功能
		if($_SESSION['uname']){
			$arr=array('password'=>md5($in['password']),);
			$return = M('user')->where("username='{$_SESSION['uname']}'")->save($arr);
		}	
		$rel=array(
			'code'=>'0',
			'msg'=>'修改成功!',
		);
		$this->ajaxReturn($rel,'JSON');	
	}
	



	
    

}