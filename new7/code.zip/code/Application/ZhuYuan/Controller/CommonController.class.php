<?php
namespace ZhuYuan\Controller;
use Think\Controller;
class CommonController extends Controller {
}